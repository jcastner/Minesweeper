public enum Status {
    OK,
    WIN,
    MINE
}
