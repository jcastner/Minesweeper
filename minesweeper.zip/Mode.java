public enum Mode {
    BEGINNER,
    INTERMEDIATE,
    EXPERT
}
